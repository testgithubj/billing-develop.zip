/*
 * Copyright 2020(c) The Ontario Institute for Cancer Research. All rights reserved.
 *
 * This program and the accompanying materials are made available under the terms of the GNU Public
 * License v3.0. You should have received a copy of the GNU General Public License along with this
 * program. If not, see <http://www.gnu.org/licenses/>.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
 * WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

export const collectionFlattener = (item, parnetKey, stem = '') => {
    const newStem = stem ? `${stem}.${parnetKey}` : parnetKey;

    return typeof item === 'object' && !Array.isArray(item)
        ? Object.keys(item).reduce((out, key) => ({
            ...out,
            ...[out, collectionFlattener(item[key], key, newStem)].reduce(
                (newItems, subItem) => {
                    Object.keys(subItem).forEach(subKey => {
                        newItems[subKey] = subItem[subKey];
                    });
                    return newItems;
                }, {},
            ),
        }), {})
        : { [newStem]: item };
};

export const customNumberSort = (a, b, order, field) => ((order === 'desc')
    ? a[field] - b[field]
    : b[field] - a[field]);
